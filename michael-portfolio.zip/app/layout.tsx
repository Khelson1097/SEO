import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Michael Yunson | Virtual Assistant | SEO Specialist | Web Designer",
  description:
    "Michael Yunson is a Filipino Virtual Assistant specializing in SEO, lead generation, telesales, and web design. Helping businesses grow online with digital solutions.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
